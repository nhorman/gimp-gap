#include "mpeg3audio.h"

int mpeg3audio_dolayer1(mpeg3audio_t *audio)
{
	;
}
